<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html SYSTEM "http://evolvis.org/DTD/xhtml10t-rdfa10.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:doap="http://usefulinc.com/ns/doap#" xmlns:foaf="http://xmlns.com/foaf/0.1/" xmlns:planetforge="http://coclico-project.org/ontology/planetforge#" xmlns:sioc="http://rdfs.org/sioc/ns#">
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>R-Forge: DEoptim: SCM Repository</title><link rel="icon" type="image/png" href="https://r-forge.r-project.org/favicon.ico" /><link rel="shortcut icon" type="image/png" href="https://r-forge.r-project.org/favicon.ico" />
                                <link rel="alternate" title="R-Forge - Project News Highlights RSS" href="https://r-forge.r-project.org/export/rss_sfnews.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - Project News Highlights RSS 2.0" href="https://r-forge.r-project.org/export/rss20_news.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - New Projects RSS" href="https://r-forge.r-project.org/export/rss_sfprojects.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - New Activity RSS" href="https://r-forge.r-project.org/export/rss20_activity.php?group_id=0" type="application/rss+xml"/><link rel="search" title="R-Forge" href="https://r-forge.r-project.org/export/search_plugin.php" type="application/opensearchdescription+xml"/>
			<link rel="stylesheet" type="text/css" href="/scripts/yui/reset-fonts-grids/reset-fonts-grids.css?1288118714"/>
			<link rel="stylesheet" type="text/css" href="/scripts/yui/base/base-min.css?1288118710"/>
			<link rel="stylesheet" type="text/css" href="/themes/css/fusionforge.css?1326483184"/>
			<link rel="stylesheet" type="text/css" href="/themes/rforge/css/theme.css?1328696305"/>
			<link rel="stylesheet" type="text/css" href="/themes/rforge/css/theme-pages.css?1305808785"/>

			<script type="text/javascript" src="/scripts/prototype/prototype.js"></script>
			<script type="text/javascript" src="/scripts/scriptaculous/scriptaculous.js"></script>
			<script type="text/javascript" src="/scripts/codendi/Tooltip.js"></script>
			<script type="text/javascript" src="/scripts/codendi/LayoutManager.js"></script>
			<script type="text/javascript" src="/scripts/codendi/ReorderColumns.js"></script>
			<script type="text/javascript" src="/scripts/codendi/codendi-1236793993.js"></script>
			<script type="text/javascript" src="/scripts/codendi/validate.js"></script>
			<script type="text/javascript" src="/js/common.js"></script>
			<script language="JavaScript" type="text/javascript">/* <![CDATA[ */
			/* ]]> */</script>			<meta name="Forge-Identification" content="FusionForge:5.1.1" />
			</head>
					<body>
			
			<table id="header" class="width-100p100">
				<tr>
					<td id="header-col1"><a href="/"><img src="https://r-forge.r-project.org/themes/rforge/imagesrf/logo.png" alt="R-Forge Home" width="192" height="54" /></a></td>
					<td id="header-col2"><form id="searchBox" action="/search/" method="get">
                         <div><select name="type_of_search"><option value="soft">Project</option>
<option value="people">People</option>
</select><input type="hidden" value="0" name="group_id" />
<input type="text" size="12" id="searchBox-words" name="words" value="" />
<input type="submit" name="Search" value="Search" />
</div></form>
					</td>
					<td id="header-col3">
			<a class="userlink" href="https://r-forge.r-project.org/account/login.php?return_to=%2Fscm%2Fviewvc.php%2Fpkg%2FDEoptim%2Finst%2Fdoc%2Frandom_portfolios.R%3Fview%3Dmarkup%26root%3Ddeoptim%26sortby%3Drev%26pathrev%3D94">Log In</a> | <a class="userlink" href="/account/register.php">New Account</a>
					</td>
				</tr>
			</table>
			
			<!-- outer tabs -->
			
		<!-- start tabs -->
		<table class="tabGenerator width-100p100" summary="" >
<tr>
<td class="tg-left">
<div class="selected"><div>
</div></div>
</td>
<td class="tg-middle" style="width:34%;">
<div class="selected"><div>
<a href="/">Home</a>
</div></div>
</td>
<td class="tg-right">
<div class="selected"><div>
</div></div>
</td>

<td class="tg-left">
<div><div>
</div></div>
</td>
<td class="tg-middle" style="width:33%;">
<div><div>
<a href="/my/">My&nbsp;Page</a>
</div></div>
</td>
<td class="tg-right">
<div><div>
</div></div>
</td>

<td class="tg-left">
<div><div>
</div></div>
</td>
<td class="tg-middle" style="width:33%;">
<div><div>
<a href="/softwaremap/">Projects</a>
</div></div>
</td>
<td class="tg-right">
<div><div>
</div></div>
</td>
</tr>
        </table>
        <!-- end tabs --><!-- inner tabs -->

		<!-- start tabs -->
		<table class="tabGenerator width-100p100" summary="" >
<tr>
<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/projects/deoptim/">Summary</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/activity/?group_id=773">Activity</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/mail/?group_id=773">Lists</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div class="selected"><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div class="selected"><div class="nested">
<a href="/scm/?group_id=773">SCM</a>
</div></div>
</td>
<td class="tg-right">
<div class="selected"><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/R/?group_id=773">R Packages</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>
</tr>
        </table>
        <!-- end tabs --><div id="maindiv">
<h1>SCM Repository</h1><div id="scm" class="scm"><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<!-- ViewVC :: http://www.viewvc.org/ -->
<head>
<title>[deoptim] View of /pkg/DEoptim/inst/doc/random_portfolios.R</title>
<meta name="generator" content="ViewVC 1.0.0" />
<link rel="stylesheet" href="/themes/rforge/viewvc/styles.css" type="text/css" />

</head>
<body>
<div class="vc_navheader">
<table style="padding:0.1em;">
<tr>
<td>
<strong>

<a href="/scm/viewvc.php/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

[deoptim]</a>
/

<a href="/scm/viewvc.php/pkg/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

pkg</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

DEoptim</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

inst</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

doc</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/random_portfolios.R?view=log&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94">

random_portfolios.R</a>


</strong>

</td>
<td style="text-align:right;">
&nbsp;
</td>
</tr>
</table>
</div>
<div style="float: right; padding: 5px;"><a href="http://www.viewvc.org/"><img src="/themes/rforge/viewvc/images/logo.png" alt="ViewVC logotype" width="128" height="48" /></a></div>
<h1>View of /pkg/DEoptim/inst/doc/random_portfolios.R</h1>

<p style="margin:0;">

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/?root=deoptim&amp;sortby=rev&amp;pathrev=94"><img src="/themes/rforge/viewvc/images/back_small.png" width="16" height="16" alt="Parent Directory" /> Parent Directory</a>

| <a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/random_portfolios.R?view=log&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94"><img src="/themes/rforge/viewvc/images/log.png" width="16" height="16" alt="Revision Log" /> Revision Log</a>




</p>

<hr />
<div class="vc_summary">
Revision <a href="/scm/viewvc.php?view=rev&amp;root=deoptim&amp;sortby=rev&amp;revision=92"><strong>92</strong></a> -
(<a href="/scm/viewvc.php/*checkout*/pkg/DEoptim/inst/doc/random_portfolios.R?revision=92&amp;root=deoptim&amp;pathrev=94"><strong>download</strong></a>)

(<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/random_portfolios.R?annotate=92&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94"><strong>annotate</strong></a>)

<br /><em>Wed Mar 21 20:44:32 2012 UTC</em>
(13 days, 23 hours ago)
by <em>kmm</em>






<br />File size: 9532 byte(s)



<pre class="vc_log">vignette depends fixed</pre>

</div>
<div id="vc_markup"><pre>###############################################################################
# R (<a href="http://r-project.org/">http://r-project.org/</a>) Numeric Methods for Optimization of Portfolios
#
# Copyright (c) 2004-2010 Kris Boudt, Peter Carl and Brian G. Peterson
#
# This library is distributed under the terms of the GNU Public License (GPL)
# for full details see the file COPYING
#
# $Id$
#
###############################################################################

# functions to build portfolios for use by the optimizer

# this code may be made obsolete by the advanced (non-linear, MIP) fPortfolio or roi optimizers, but for now, they are beta code at best

# require(LSPM) # for the un-exported .nPri functions
# generate all feasible portfolios
#LSPM:::.nPri(n=13,r=45,i=n^r,replace=TRUE)
# not likely to actually BE feasible for any portfolio of real size, but I'll write the grid generator anyway that will generate all the permutations, and kick out only the feasible portfolios


# random portfolios


#' create a sequence of possible weights for random or brute force portfolios
#' 
#' This function creates the sequence of min&lt;-&gt;max weights for use by
#' random or brute force optimization engines.
#' 
#' The sequence created is not constrained by asset. 
#' 
#' @param min minimum value of the sequence
#' @param max maximum value of the sequence
#' @param by number to increment the sequence by
#' @param rounding integrer how many decimals should we round to
#' @author Peter Carl, Brian G. Peterson
#' @seealso \code{\link{constraint}}, \code{\link{objective}}
#' @export
#' @callGraph
generatesequence &lt;- function (min=.01, max=1, by=min/max, rounding=3 )
{ 
  # this creates the sequence of possible weights, not constrained by asset
  ret &lt;- seq(from = round(min,rounding), to = round(max,rounding), by = by)
  return(ret)
}

#randomize_portfolio &lt;- function (seed, weight_seq, min_mult=-Inf,max_mult=Inf, min_sum=.99, max_sum=1.01, max_permutations=100,rounding=3)
#' generate random permutations of a portfolio seed meeting your constraints on the weights of each asset
#' 
#' @param rpconstraints an object of type "constraints" specifying the constraints for the optimization, see \code{\link{constraint}}
#' @param max_permutations integer: maximum number of iterations to try for a valid portfolio, default 200
#' @param rounding integer how many decimals should we round to
#' @callGraph
#' @return named weighting vector
#' @author Peter Carl, Brian G. Peterson, (based on an idea by Pat Burns)
#' @export
#' @callGraph
randomize_portfolio &lt;- function (rpconstraints, max_permutations=200, rounding=3)

{ # @author: Peter Carl, Brian Peterson (based on an idea by Pat Burns)
  # generate random permutations of a portfolio seed meeting your constraints on the weights of each asset
  # set the portfolio to the seed
  seed=rpconstraints$assets
  nassets= length(seed)
  min_mult=rpconstraints$min_mult
  if(is.null(min_mult)) min_mult= rep(-Inf,nassets)
  max_mult=rpconstraints$max_mult
  if(is.null(max_mult)) max_mult= rep(Inf,nassets)
  min_sum =rpconstraints$min_sum
  max_sum =rpconstraints$max_sum
  weight_seq=rpconstraints$weight_seq
  portfolio=as.vector(seed)
  max     = rpconstraints$max
  min     = rpconstraints$min 
  rownames(portfolio)&lt;-NULL
  weight_seq=as.vector(weight_seq)
  # initialize our loop
  permutations=1

    # create a temporary portfolio so we don't return a non-feasible portfolio
    tportfolio=portfolio
    # first randomly permute each element of the temporary portfolio
    random_index &lt;- sample(1:length(tportfolio),length(tportfolio))
    for (i in 1:length(tportfolio)) {
       cur_index&lt;-random_index[i]
       cur_val &lt;- tportfolio[cur_index]
       # randomly permute a random portfolio element
       tportfolio[cur_index]&lt;-sample(weight_seq[(weight_seq&gt;=cur_val*min_mult[cur_index]) &amp; (weight_seq&lt;=cur_val*max_mult[cur_index]) &amp; (weight_seq&lt;=max[cur_index]) &amp; (weight_seq&gt;=min[cur_index])],1)
    }
      
  #while portfolio is outside min/max sum and we have not reached max_permutations
  while ((sum(tportfolio)&lt;=min_sum | sum(tportfolio)&gt;=max_sum) &amp; permutations&lt;=max_permutations) {
        permutations=permutations+1
        # check our box constraints on total portfolio weight
        # reduce(increase) total portfolio size till you get a match
        # 1&gt; check to see which bound you've failed on, brobably set this as a pair of while loops
        # 2&gt; randomly select a column and move only in the direction *towards the bound*, maybe call a function inside a function
        # 3&gt; check and repeat
        random_index &lt;- sample(1:length(tportfolio), length(tportfolio))
        i = 1
        while (sum(tportfolio)&lt;=min_sum &amp; i&lt;=length(tportfolio)) {
          # randomly permute and increase a random portfolio element
          cur_index&lt;-random_index[i]
          cur_val &lt;- tportfolio[cur_index]
            if (length(weight_seq[(weight_seq&gt;=cur_val)&amp;(weight_seq&lt;=max[cur_index])])&gt;1)
            {
              # randomly sample one of the larger weights
              tportfolio[cur_index]&lt;-sample(weight_seq[(weight_seq&gt;=cur_val)&amp;(weight_seq&lt;=max[cur_index])],1)
              # print(paste("new val:",tportfolio[cur_index]))
            } else {
              if (length(weight_seq[(weight_seq&gt;=cur_val)&amp;(weight_seq&lt;=max[cur_index])]) == 1) {
                tportfolio[cur_index]&lt;-weight_seq[(weight_seq&gt;=cur_val)&amp;(weight_seq&lt;=max[cur_index])]
              }
            }
          i=i+1 # increment our counter
        } # end increase loop
        while (sum(tportfolio)&gt;=max_sum &amp; i&lt;=length(tportfolio)) {
          # randomly permute and decrease a random portfolio element
          cur_index&lt;-random_index[i]
          cur_val &lt;- tportfolio[cur_index]
            if (length(weight_seq&lt;=cur_val &amp; weight_seq&gt;=min[cur_index] )&gt;1) {
              tportfolio[cur_index]&lt;-sample(weight_seq[which(weight_seq&lt;=cur_val &amp; weight_seq&gt;=min[cur_index] )],1)
            } else {
              if (length(weight_seq&lt;=cur_val &amp; weight_seq&gt;=min[cur_index] )==1) {
                tportfolio[cur_index]&lt;-weight_seq[(weight_seq&lt;=cur_val) &amp; (weight_seq&gt;=min[cur_index])]
              }
            }
          i=i+1 # increment our counter
        } # end decrease loop
  } # end final walk towards the edges

  portfolio&lt;-tportfolio

  colnames(portfolio)&lt;-colnames(seed)
  if (sum(portfolio)&lt;=min_sum | sum(tportfolio)&gt;=max_sum){
        portfolio &lt;- seed
        warning("Infeasible portfolio created, defaulting to seed, perhaps increase max_permutations.")
  }
  if(isTRUE(all.equal(seed,portfolio))) {
    if (sum(seed)&gt;=min_sum &amp; sum(seed)&lt;=max_sum) {
      warning("Unable to generate a feasible portfolio different from seed, perhaps adjust your parameters.")
      return(seed)
    } else {
      warning("Unable to generate a feasible portfolio, perhaps adjust your parameters.")
      return(NULL)
    }
  }
  return(portfolio)
}

#' deprecated random portfolios wrapper until we write a random trades function
#' 
#' 
#' @param ... any other passthru parameters
#' @author bpeterson
#' @export
random_walk_portfolios &lt;-function(...) {
  # wrapper function protect older code for now?
  random_portfolios(...=...)
}

#' generate an arbitary number of constrained random portfolios
#' 
#' repeatedly calls \code{\link{randomize_portfolio}} to generate an 
#' arbitrary number of constrained random portfolios.
#' 
#' @param rpconstraints an object of type "constraints" specifying the constraints for the optimization, see \code{\link{constraint}}
#' @param permutations integer: number of unique constrained random portfolios to generate
#' @param \dots any other passthru parameters 
#' @return matrix of random portfolio weights
#' @seealso \code{\link{constraint}}, \code{\link{objective}}, \code{\link{randomize_portfolio}}
#' @author Peter Carl, Brian G. Peterson, (based on an idea by Pat Burns)
#' @export
#' @examples
#' rpconstraint&lt;-constraint(assets=10, min_mult=-Inf, max_mult=Inf, min_sum=.99, max_sum=1.01, min=.01, max=.4, weight_seq=generatesequence())
#' rp&lt;- random_portfolios(rpconstraints=rpconstraint,permutations=1000)
#' head(rp)
#' @callGraph
random_portfolios &lt;- function (rpconstraints,permutations=100,...)
{ # 
  # this function generates a series of portfolios that are a "random walk" from the current portfolio
  seed=rpconstraints$assets
  result &lt;- matrix(nrow=permutations, ncol=length(seed))
  result[1,]&lt;-seed
  result[2,]&lt;-rep(1/length(seed),length(seed))
#  rownames(result)[1]&lt;-"seed.portfolio"
#  rownames(result)[2]&lt;-"equal.weight"
  i &lt;- 3
  while (i&lt;=permutations) {
    result[i,] &lt;- as.matrix(randomize_portfolio(rpconstraints=rpconstraints, ...))
    if(i==permutations) {
      result = unique(result)
      i = nrow(result)
      result = rbind(result, matrix(nrow=(permutations-i),ncol=length(seed)))
    }
    i&lt;-i+1
  }
  colnames(result)&lt;-names(seed)
  return(result)
}

# EXAMPLE: start_t&lt;- Sys.time(); x=random_walk_portfolios(rep(1/5,5), generatesequence(min=0.01, max=0.30, by=0.01), max_permutations=500, permutations=5000, min_sum=.99, max_sum=1.01); end_t&lt;-Sys.time(); end_t-start_t;
# &gt; nrow(unique(x))
# [1] 4906
# &gt; which(rowSums(x)&lt;.99 | rowSums(x)&gt;1.01)
# integer(0)

# start_t &lt;- Sys.time(); s&lt;-foreach(seed=iter(weights, by='row'),.combine=rbind) %dopar% random_walk_portfolios(seed,xseq,permutations=10000); end_t &lt;- Sys.time(); save.image(); start_t-end_t;

# TODO: write a function for random trades that only makes n trades and increases/decreases other elements to compensate.
</pre></div>

<hr />
<table>
<tr>
<td><address><a href='mailto:root@r-forge.r-project.org'>root@r-forge.r-project.org</a></address></td>
<td style="text-align: right;"><strong><a href="/themes/rforge/viewvc/help_rootview.html">ViewVC Help</strong></td>
</tr>
<tr>
<td>Powered by <a href="http://viewvc.tigris.org/">ViewVC 1.0.0</a></td>
<td style="text-align: right;">&nbsp;</td>
</tr>
</table>
</body>
</html>

</div></div><!-- id="maindiv" -->
   <table border="0" cellpadding="0" cellspacing="0" align="center" style="border:auto;padding:auto;margin:auto;">
      <tr>
        <td align="center">
          Thanks to:
          <table cellpadding="4" cellspacing="4" border="0">
            <tr>
              <td>
                <a href="http://www.wu.ac.at">
                <img src="https://r-forge.r-project.org/themes/rforge/imagesrf/wu_vienna.png" border="0" alt="Vienna University of Economics and Business" /> 
                </a>
              </td>
              <td>
                <a href="http://www.stat.wisc.edu/">
                <img src="https://r-forge.r-project.org/themes/rforge/imagesrf/banners/uwlogo-crest.jpg" border="0" alt="University of Wisconsin - Madison" /> 
                </a>
              </td>
              <td>
                <a href="http://fusionforge.org/"><img src="https://r-forge.r-project.org/themes/rforge/imagesrf/pow-fusionforge.png" alt="Powered By FusionForge" border="0" /></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

