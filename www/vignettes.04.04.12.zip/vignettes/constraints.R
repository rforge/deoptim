<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html SYSTEM "http://evolvis.org/DTD/xhtml10t-rdfa10.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:doap="http://usefulinc.com/ns/doap#" xmlns:foaf="http://xmlns.com/foaf/0.1/" xmlns:planetforge="http://coclico-project.org/ontology/planetforge#" xmlns:sioc="http://rdfs.org/sioc/ns#">
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>R-Forge: DEoptim: SCM Repository</title><link rel="icon" type="image/png" href="https://r-forge.r-project.org/favicon.ico" /><link rel="shortcut icon" type="image/png" href="https://r-forge.r-project.org/favicon.ico" />
                                <link rel="alternate" title="R-Forge - Project News Highlights RSS" href="https://r-forge.r-project.org/export/rss_sfnews.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - Project News Highlights RSS 2.0" href="https://r-forge.r-project.org/export/rss20_news.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - New Projects RSS" href="https://r-forge.r-project.org/export/rss_sfprojects.php" type="application/rss+xml"/>
                                <link rel="alternate" title="R-Forge - New Activity RSS" href="https://r-forge.r-project.org/export/rss20_activity.php?group_id=0" type="application/rss+xml"/><link rel="search" title="R-Forge" href="https://r-forge.r-project.org/export/search_plugin.php" type="application/opensearchdescription+xml"/>
			<link rel="stylesheet" type="text/css" href="/scripts/yui/reset-fonts-grids/reset-fonts-grids.css?1288118714"/>
			<link rel="stylesheet" type="text/css" href="/scripts/yui/base/base-min.css?1288118710"/>
			<link rel="stylesheet" type="text/css" href="/themes/css/fusionforge.css?1326483184"/>
			<link rel="stylesheet" type="text/css" href="/themes/rforge/css/theme.css?1328696305"/>
			<link rel="stylesheet" type="text/css" href="/themes/rforge/css/theme-pages.css?1305808785"/>

			<script type="text/javascript" src="/scripts/prototype/prototype.js"></script>
			<script type="text/javascript" src="/scripts/scriptaculous/scriptaculous.js"></script>
			<script type="text/javascript" src="/scripts/codendi/Tooltip.js"></script>
			<script type="text/javascript" src="/scripts/codendi/LayoutManager.js"></script>
			<script type="text/javascript" src="/scripts/codendi/ReorderColumns.js"></script>
			<script type="text/javascript" src="/scripts/codendi/codendi-1236793993.js"></script>
			<script type="text/javascript" src="/scripts/codendi/validate.js"></script>
			<script type="text/javascript" src="/js/common.js"></script>
			<script language="JavaScript" type="text/javascript">/* <![CDATA[ */
			/* ]]> */</script>			<meta name="Forge-Identification" content="FusionForge:5.1.1" />
			</head>
					<body>
			
			<table id="header" class="width-100p100">
				<tr>
					<td id="header-col1"><a href="/"><img src="https://r-forge.r-project.org/themes/rforge/imagesrf/logo.png" alt="R-Forge Home" width="192" height="54" /></a></td>
					<td id="header-col2"><form id="searchBox" action="/search/" method="get">
                         <div><select name="type_of_search"><option value="soft">Project</option>
<option value="people">People</option>
</select><input type="hidden" value="0" name="group_id" />
<input type="text" size="12" id="searchBox-words" name="words" value="" />
<input type="submit" name="Search" value="Search" />
</div></form>
					</td>
					<td id="header-col3">
			<a class="userlink" href="https://r-forge.r-project.org/account/login.php?return_to=%2Fscm%2Fviewvc.php%2Fpkg%2FDEoptim%2Finst%2Fdoc%2Fconstraints.R%3Fview%3Dmarkup%26root%3Ddeoptim%26sortby%3Drev%26pathrev%3D94">Log In</a> | <a class="userlink" href="/account/register.php">New Account</a>
					</td>
				</tr>
			</table>
			
			<!-- outer tabs -->
			
		<!-- start tabs -->
		<table class="tabGenerator width-100p100" summary="" >
<tr>
<td class="tg-left">
<div class="selected"><div>
</div></div>
</td>
<td class="tg-middle" style="width:34%;">
<div class="selected"><div>
<a href="/">Home</a>
</div></div>
</td>
<td class="tg-right">
<div class="selected"><div>
</div></div>
</td>

<td class="tg-left">
<div><div>
</div></div>
</td>
<td class="tg-middle" style="width:33%;">
<div><div>
<a href="/my/">My&nbsp;Page</a>
</div></div>
</td>
<td class="tg-right">
<div><div>
</div></div>
</td>

<td class="tg-left">
<div><div>
</div></div>
</td>
<td class="tg-middle" style="width:33%;">
<div><div>
<a href="/softwaremap/">Projects</a>
</div></div>
</td>
<td class="tg-right">
<div><div>
</div></div>
</td>
</tr>
        </table>
        <!-- end tabs --><!-- inner tabs -->

		<!-- start tabs -->
		<table class="tabGenerator width-100p100" summary="" >
<tr>
<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/projects/deoptim/">Summary</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/activity/?group_id=773">Activity</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/mail/?group_id=773">Lists</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div class="selected"><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div class="selected"><div class="nested">
<a href="/scm/?group_id=773">SCM</a>
</div></div>
</td>
<td class="tg-right">
<div class="selected"><div class="nested">
</div></div>
</td>

<td class="tg-left">
<div><div class="nested">
</div></div>
</td>
<td class="tg-middle" style="width:20%;">
<div><div class="nested">
<a href="/R/?group_id=773">R Packages</a>
</div></div>
</td>
<td class="tg-right">
<div><div class="nested">
</div></div>
</td>
</tr>
        </table>
        <!-- end tabs --><div id="maindiv">
<h1>SCM Repository</h1><div id="scm" class="scm"><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<!-- ViewVC :: http://www.viewvc.org/ -->
<head>
<title>[deoptim] View of /pkg/DEoptim/inst/doc/constraints.R</title>
<meta name="generator" content="ViewVC 1.0.0" />
<link rel="stylesheet" href="/themes/rforge/viewvc/styles.css" type="text/css" />

</head>
<body>
<div class="vc_navheader">
<table style="padding:0.1em;">
<tr>
<td>
<strong>

<a href="/scm/viewvc.php/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

[deoptim]</a>
/

<a href="/scm/viewvc.php/pkg/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

pkg</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

DEoptim</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

inst</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/?root=deoptim&amp;sortby=rev&amp;pathrev=94">

doc</a>
/

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/constraints.R?view=log&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94">

constraints.R</a>


</strong>

</td>
<td style="text-align:right;">
&nbsp;
</td>
</tr>
</table>
</div>
<div style="float: right; padding: 5px;"><a href="http://www.viewvc.org/"><img src="/themes/rforge/viewvc/images/logo.png" alt="ViewVC logotype" width="128" height="48" /></a></div>
<h1>View of /pkg/DEoptim/inst/doc/constraints.R</h1>

<p style="margin:0;">

<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/?root=deoptim&amp;sortby=rev&amp;pathrev=94"><img src="/themes/rforge/viewvc/images/back_small.png" width="16" height="16" alt="Parent Directory" /> Parent Directory</a>

| <a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/constraints.R?view=log&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94"><img src="/themes/rforge/viewvc/images/log.png" width="16" height="16" alt="Revision Log" /> Revision Log</a>




</p>

<hr />
<div class="vc_summary">
Revision <a href="/scm/viewvc.php?view=rev&amp;root=deoptim&amp;sortby=rev&amp;revision=92"><strong>92</strong></a> -
(<a href="/scm/viewvc.php/*checkout*/pkg/DEoptim/inst/doc/constraints.R?revision=92&amp;root=deoptim&amp;pathrev=94"><strong>download</strong></a>)

(<a href="/scm/viewvc.php/pkg/DEoptim/inst/doc/constraints.R?annotate=92&amp;root=deoptim&amp;sortby=rev&amp;pathrev=94"><strong>annotate</strong></a>)

<br /><em>Wed Mar 21 20:44:32 2012 UTC</em>
(13 days, 23 hours ago)
by <em>kmm</em>






<br />File size: 7485 byte(s)



<pre class="vc_log">vignette depends fixed</pre>

</div>
<div id="vc_markup"><pre>###############################################################################
# R (<a href="http://r-project.org/">http://r-project.org/</a>) Numeric Methods for Optimization of Portfolios
#
# Copyright (c) 2004-2010 Kris Boudt, Peter Carl and Brian G. Peterson
#
# This library is distributed under the terms of the GNU Public License (GPL)
# for full details see the file COPYING
#
# $Id$
#
###############################################################################

#' constructor for class constraint
#' 
#' @param assets number of assets, or optionally a named vector of assets specifying seed weights
#' @param ... any other passthru parameters
#' @param min numeric or named vector specifying minimum weight box constraints
#' @param max numeric or named vector specifying minimum weight box constraints
#' @param min_mult numeric or named vector specifying minimum multiplier box constraint from seed weight in \code{assets}
#' @param max_mult numeric or named vector specifying maximum multiplier box constraint from seed weight in \code{assets}
#' @param min_sum minimum sum of all asset weights, default .99
#' @param max_sum maximum sum of all asset weights, default 1.01
#' @param weight_seq seed sequence of weights, see \code{\link{generatesequence}}
#' @author Peter Carl and Brian G. Peterson
#' @examples 
#' exconstr &lt;- constraint(assets=10, min_sum=1, max_sum=1, min=.01, max=.35, weight_seq=generatesequence())
#' @export
#' @callGraph
constraint &lt;- function(assets=NULL, ... ,min,max,min_mult,max_mult,min_sum=.99,max_sum=1.01,weight_seq=NULL)
{ # based on GPL R-Forge pkg roi by Stefan Thuessel,Kurt Hornik,David Meyer
  if (hasArg(min) &amp; hasArg(max)) {
    if (is.null(assets) &amp; (!length(min)&gt;1) &amp; (!length(max)&gt;1)) {
      stop("You must either specify the assets or pass a vector for both min and max")
    }
  }

  if(!is.null(assets)){
    # TODO FIXME this doesn't work quite right on matrix of assets
    if(is.numeric(assets)){
      if (length(assets) == 1) {
        nassets=assets
        #we passed in a number of assets, so we need to create the vector
        message("assuming equal weighted seed portfolio")
        assets&lt;-rep(1/nassets,nassets)
      } else {
        nassets = length(assets)
      }
      # and now we may need to name them
      if (is.null(names(assets))) {
        for(i in 1:length(assets)){
          names(assets)[i]&lt;-paste("Asset",i,sep=".")
        }
      }
    }
    if(is.character(assets)){
      nassets=length(assets)
      assetnames=assets
      message("assuming equal weighted seed portfolio")
      assets&lt;-rep(1/nassets,nassets)
      names(assets)&lt;-assetnames  # set names, so that other code can access it,
      # and doesn't have to know about the character vector
      # print(assets)
    }
    # if assets is a named vector, we'll assume it is current weights
  }

  if(hasArg(min) | hasArg(max)) {
    if (length(min)&gt;1 &amp; length(max)&gt;1){
      if (length(min)!=length(max)) { stop("length of min and max must be the same") }
    } 

    if (length(min)==1) {
        message("min not passed in as vector, replicating min to length of length(assets)")
        min &lt;- rep(min,nassets)
    }
    if (length(min)!=nassets) stop(paste("length of min must be equal to 1 or the number of assets",nassets))
    
    if (length(max)==1) {
        message("max not passed in as vector, replicating max to length of length(assets)")
        max &lt;- rep(max,nassets)
    }
    if (length(max)!=nassets) stop(paste("length of max must be equal to 1 or the number of assets",nassets))
    
  } else {
    message("no min or max passed in, assuming 0 and 1")
    min &lt;- rep(0,nassets)
    max &lt;- rep(1,nassets)
  }

  names(min)&lt;-names(assets)
  names(max)&lt;-names(assets)
  
  if(hasArg(min_mult) | hasArg(max_mult)) {
    if (length(min_mult)&gt;1 &amp; length(max_mult)&gt;1){
      if (length(min_mult)!=length(max_mult) ) { stop("length of min_mult and max_mult must be the same") }
    } else {
      message("min_mult and max_mult not passed in as vectors, replicating min_mult and max_mult to length of assets vector")
      min_mult = rep(min_mult,nassets)
      max_mult = rep(max_mult,nassets)
    }
  }

  if(!hasArg(min_sum) | !hasArg(max_sum)) {
    min_sum = NULL
    max_sum = NULL 
  }

  if (!is.null(names(assets))) {
    assetnames&lt;-names(assets)
    if(hasArg(min)){
      names(min)&lt;-assetnames
      names(max)&lt;-assetnames
    } else {
      min = NULL
      max = NULL
    }
    if(hasArg(min_mult)){
      names(min_mult)&lt;-assetnames
      names(max_mult)&lt;-assetnames
    } else {
      min_mult = NULL
      max_mult = NULL
    }
  }
  ##now adjust min and max to account for min_mult and max_mult from seed
  if(!is.null(min_mult) &amp; !is.null(min)) {
    tmp_min &lt;- assets*min_mult
    #TODO FIXME this creates a list, and it should create a named vector or matrix
    min[which(tmp_min&gt;min)]&lt;-tmp_min[which(tmp_min&gt;min)]
  }
  if(!is.null(max_mult) &amp; !is.null(max)) {
    tmp_max &lt;- assets*max_mult
    #TODO FIXME this creates a list, and it should create a named vector or matrix
    max[which(tmp_max&lt;max)]&lt;-tmp_max[which(tmp_max&lt;max)]
  }

  ## now structure and return
  return(structure(
    list(
      assets = assets,
      min = min,
      max = max,
      min_mult = min_mult,
      max_mult = max_mult,
      min_sum  = min_sum,
      max_sum  = max_sum,
      weight_seq = weight_seq,
      objectives = list(),
      call = match.call()
    ),
    class=c("v1_constraint","constraint")
  ))
}

#' check function for constraints
#' 
#' @param x object to test for type \code{constraint}
#' @author bpeterson
#' @export
is.constraint &lt;- function( x ) {
  inherits( x, "constraint" )
}

#' function for updating constrints, not well tested, may be broken
#' 
#' can we use the generic update.default function?
#' @param object object of type \code{\link{constraint}} to update
#' @param ... any other passthru parameters, used to call \code{\link{constraint}}
#' @author bpeterson
update.constraint &lt;- function(object, ...){
  constraints &lt;- object
  if (is.null(constraints) | !is.constraint(constraints)){
    stop("you must pass in an object of class constraints to modify")
  }
  call &lt;- object$call
  if (is.null(call))
      stop("need an object with call component")
  extras &lt;- match.call(expand.dots = FALSE)$...
#   if (!missing(formula.))
#       call$formula &lt;- update.formula(formula(object), formula.)
  if (length(extras)) {
      existing &lt;- !is.na(match(names(extras), names(call)))
      for (a in names(extras)[existing]) call[[a]] &lt;- extras[[a]]
      if (any(!existing)) {
          call &lt;- c(as.list(call), extras[!existing])
          call &lt;- as.call(call)
      }
  }
#   if (hasArg(nassets)){
#     warning("changing number of assets may modify other constraints")
#     constraints$nassets&lt;-nassets
#   }
#   if(hasArg(min)) {
#     if (is.vector(min) &amp; length(min)!=nassets){
#       warning(paste("length of min !=",nassets))
#       if (length(min)&lt;nassets) {stop("length of min must be equal to lor longer than nassets")}
#       constraints$min&lt;-min[1:nassets]
#     }
#   }
#   if(hasArg(max)) {
#     if (is.vector(max) &amp; length(max)!=nassets){
#       warning(paste("length of max !=",nassets))
#       if (length(max)&lt;nassets) {stop("length of max must be equal to lor longer than nassets")}
#       constraints$max&lt;-max[1:nassets]
#     }
#   }
#   if(hasArg(min_mult)){constrains$min_mult=min_mult}
#   if(hasArg(max_mult)){constrains$max_mult=max_mult}
  return(constraints)
}

</pre></div>

<hr />
<table>
<tr>
<td><address><a href='mailto:root@r-forge.r-project.org'>root@r-forge.r-project.org</a></address></td>
<td style="text-align: right;"><strong><a href="/themes/rforge/viewvc/help_rootview.html">ViewVC Help</strong></td>
</tr>
<tr>
<td>Powered by <a href="http://viewvc.tigris.org/">ViewVC 1.0.0</a></td>
<td style="text-align: right;">&nbsp;</td>
</tr>
</table>
</body>
</html>

</div></div><!-- id="maindiv" -->
   <table border="0" cellpadding="0" cellspacing="0" align="center" style="border:auto;padding:auto;margin:auto;">
      <tr>
        <td align="center">
          Thanks to:
          <table cellpadding="4" cellspacing="4" border="0">
            <tr>
              <td>
                <a href="http://www.wu.ac.at">
                <img src="https://r-forge.r-project.org/themes/rforge/imagesrf/wu_vienna.png" border="0" alt="Vienna University of Economics and Business" /> 
                </a>
              </td>
              <td>
                <a href="http://www.stat.wisc.edu/">
                <img src="https://r-forge.r-project.org/themes/rforge/imagesrf/banners/uwlogo-crest.jpg" border="0" alt="University of Wisconsin - Madison" /> 
                </a>
              </td>
              <td>
                <a href="http://fusionforge.org/"><img src="https://r-forge.r-project.org/themes/rforge/imagesrf/pow-fusionforge.png" alt="Powered By FusionForge" border="0" /></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

